#ifndef CALCULATRICE_H
#define CALCULATRICE_H
#include <QLineEdit>
#include <QGridLayout>
#include <QPushButton>
#include <QWidget>
#define NBTOUCHES 16

QT_BEGIN_NAMESPACE
namespace Ui {
class Calculatrice;
}
QT_END_NAMESPACE

class Calculatrice : public QWidget
{
    Q_OBJECT

public:
    Calculatrice(QWidget *parent = nullptr);
    ~Calculatrice();

public slots:
    void onQPushButtonClicked();
private:
    Ui::Calculatrice *ui;
    QLineEdit * afficheur;
    QGridLayout * grille;
    QPushButton * touches[NBTOUCHES];
    QString signeActuel;
    int nbTmp;
    bool calculEnCours;
    const QString tableDesSymboles[NBTOUCHES]={"7","8","9","+","4","5","6","-","1","2","3","*","C","0","=","/"};

};
#endif // CALCULATRICE_H
