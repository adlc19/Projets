#include "calculatrice.h"
#include "ui_calculatrice.h"

Calculatrice::Calculatrice(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Calculatrice)
{
    ui->setupUi(this);
    int colonne=0, ligne=1;
    grille=new QGridLayout();
    afficheur=new QLineEdit();
    afficheur->setReadOnly(true);
    afficheur->setAlignment(Qt::AlignRight);
    grille->addWidget(afficheur, 0, 0, 1, 4);
    for (int i = 0; i < 16; ++i)
    {
        touches[i] = new QPushButton(tableDesSymboles[i], this);
        connect(touches[i], &QPushButton::clicked, this, &Calculatrice::onQPushButtonClicked);
        grille->addWidget(touches[i], ligne, colonne);
        colonne = colonne + 1;
        if (colonne == 4)
        {
            colonne = 0;
            ligne = ligne + 1;
        }
    }
    // ajout du layout à l'interface principale
    this->setLayout(grille);
}

Calculatrice::~Calculatrice()
{
    delete ui;
}

void Calculatrice::onQPushButtonClicked()
{
    QPushButton *button = qobject_cast<QPushButton *>(sender());
    QString buttonText = button->text();
    if (buttonText >= "0" && buttonText <= "9")
    {
        if (calculEnCours == true)
        {
            afficheur->clear();
            calculEnCours= false;
        }
        afficheur->setText(afficheur->text() + buttonText);
    }
    else if (buttonText== "+" || buttonText== "-"|| buttonText == "*" || buttonText == "/")
    {
        nbTmp = afficheur->text().toInt();
        signeActuel = buttonText;
        calculEnCours = true;
    }
    else if (buttonText == "=")
    {
        if (signeActuel.isEmpty()) return;

        int operandeDroite = afficheur->text().toInt();
        if (signeActuel == "+")
        {
            nbTmp += operandeDroite;
        } else if (signeActuel == "-")
        {
            nbTmp -= operandeDroite;
        } else if (signeActuel == "*")
        {
            nbTmp *= operandeDroite;
        } else if (signeActuel == "/")
        {
            if (operandeDroite != 0)
            {
                nbTmp /= operandeDroite;
            } else
            {
                afficheur->setText("Erreur");
                return;
            }
        }
        afficheur->setText(QString::number(nbTmp));
        signeActuel.clear();
        calculEnCours = true;
    }
    else if (buttonText == "C")
    {
        afficheur->clear();
        nbTmp = 0;
        signeActuel.clear();
        calculEnCours = false;
    }
}
