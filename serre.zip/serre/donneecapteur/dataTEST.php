<?php

require_once '../db/db_connect.php';  // Connexion à la base de données

$sql = "SELECT valeur, date_mesure FROM Mesure";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$donnees =
$stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encodes($donnees);
?>

