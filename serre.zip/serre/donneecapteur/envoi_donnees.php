<?php
// Activer les erreurs pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inclure le fichier de connexion
require_once '../db/db_connect.php'; // ⚠️ Remplace par le bon chemin

// Vérifier si les données GET sont présentes
if (isset($_GET['temperature']) && isset($_GET['humidite'])) {
    $temperature = $_GET['temperature'];
    $humidite = $_GET['humidite'];

    // Vérifier que les données sont bien numériques
    if (!is_numeric($temperature) || !is_numeric($humidite)) {
        exit("Données invalides.");
    }

    // Remplace ces valeurs par les vrais ID des capteurs récupérés en base !
    $id_capteur_temp = 5; // ⚠️ Mets ici l'ID du capteur de température
    $id_capteur_humid = 6; // ⚠️ Mets ici l'ID du capteur d'humidité
    $unite_temp = "°C";
    $unite_humid = "%";
    $date_mesure = date("Y-m-d H:i:s"); // Date actuelle

    // Requête préparée pour insérer la température
    $sql = "INSERT INTO Mesure (id_capteur, valeur, unité, date_mesure) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        // Insérer la température
        $stmt->bind_param("idss", $id_capteur_temp, $temperature, $unite_temp, $date_mesure);
        if (!$stmt->execute()) {
            echo "Erreur insertion température : " . $stmt->error;
        }

        // Insérer l'humidité
        $stmt->bind_param("idss", $id_capteur_humid, $humidite, $unite_humid, $date_mesure);
        if (!$stmt->execute()) {
            echo "Erreur insertion humidité : " . $stmt->error;
        } else {
            echo "Données insérées avec succès.";
        }

        $stmt->close();
    } else {
        echo "Erreur préparation requête : " . $conn->error;
    }
} else {
    echo "Données manquantes.";
}

// Fermer la connexion
$conn->close();
?>

