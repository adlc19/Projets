<?php
// Chemin où stocker les données
$file = '/var/www/serre/donneecapteur/donnees.txt';

// Récupération des données POST
$temperature = $_POST['temperature'];
$humidity = $_POST['humidity'];

// Vérification des données
if (isset($temperature) && isset($humidity)) {
    $data = date("Y-m-d H:i:s") . " | Température: $temperature °C | Humidité: $humidity %\n";

    // Enregistrement des données dans un fichier
    file_put_contents($file, $data, FILE_APPEND | LOCK_EX);

    echo "Données enregistrées avec succès !";
} else {
    echo "Erreur : données invalides.";
}
?>
