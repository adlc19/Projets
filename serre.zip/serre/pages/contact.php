<?php
session_start();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serre Connectée</title>
    
    <!-- Liens vers les fichiers CSS et librairies -->
    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <header>    
        <h1 class="fade-in">🌿 Contact</h1>
    </header>    
        <?php include '../templates/navbar.php'; ?>
    
    <section class="content">
        <h2>Nous Contacter</h2>
        <p>📧 Email : projet.serre@exemple.com</p>
        <p>📞 Téléphone : 06 XX XX XX XX</p>
    </section>
    
</body>

<?php include '../templates/footer.php'; ?>
</html>
