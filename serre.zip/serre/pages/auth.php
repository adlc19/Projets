<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// ✅ Empêcher le vol de session
session_regenerate_id(true);

// ✅ Protection contre CSRF
if ($_SERVER["REQUEST_METHOD"] == "POST" && (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token'])) {
    exit("❌ Requête invalide.");
}

// ✅ Générer un jeton CSRF unique si non défini
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ✅ Inclusion sécurisée du fichier de connexion
require_once __DIR__ . '/../db/db_connect.php';

// Vérifier si l'utilisateur est déjà connecté
if (!isset($_SESSION['user_id']) && $_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Protection contre injection SQL
    $sql = "SELECT id, username, password, role FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // Vérification de l'utilisateur
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Vérifier le mot de passe
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = htmlspecialchars($user['username']); // ✅ Protection XSS
                $_SESSION['role'] = $user['role'];

                // ✅ Redirection selon le rôle
                switch ($user['role']) {
                    case 'admin':
                        header("Location: ../admin/dashboard.php");
                        break;
                    case 'technicien':
                        header("Location: ../tech/dashboard.php");
                        break;
                    default:
                        header("Location: ../index.php");
                }
                exit();
            } else {
                // Attente pour éviter les attaques par force brute
                sleep(2);
                $error_message = "❌ Mot de passe incorrect.";
            }
        } else {
            $error_message = "❌ Utilisateur non trouvé.";
        }
        $stmt->close();
    }
}

// Vérification de la connexion
$isUserLoggedIn = isset($_SESSION['user_id']);
?>
