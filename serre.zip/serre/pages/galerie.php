<?php
session_start();

// ✅ Filtrer les fichiers d'images pour ne récupérer que les fichiers .jpg
$images = glob("../uploads/*.jpg"); 

// Sécuriser la variable de session pour vérifier si l'utilisateur est connecté
$isUserLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serre Connectée - Galerie</title>
    
    <!-- Liens CSS et bibliothèques -->
    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">
    <link rel="stylesheet" href="../assets/css/stylegaleries.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
</head>

<body>
    <!-- Header -->
    <header>    
        <h1 class="fade-in">🌿 Galerie</h1>
    </header>    

    <!-- Navigation -->
    <?php include '../templates/navbar.php'; ?>

    <div class="container">
        <main class="dashboard">
            <section class="content">
                <h2>Images Capturées</h2>

                <?php if (!$isUserLoggedIn): ?>
                    <p>🔒 L’accès aux images de la serre est réservé aux utilisateurs connectés.</p>
                    <p>Veuillez vous connecter ou créer un compte pour accéder à ces informations.</p>

                    <div class="button-container">
                        <a href="../pages/login.php"><button class="btn">🔑 Se connecter</button></a>
                        <a href="../pages/register.php"><button class="btn">📝 S'inscrire</button></a>
                    </div>
                <?php else: ?>
                    <p>✅ Vous êtes connecté ! Voici les images de la serre :</p>

                    <!-- Galerie d'images -->
                    <div class="gallery">
                        <?php foreach ($images as $image): ?>
                            <div class="image-container">
                                <img src="<?php echo htmlspecialchars($image); ?>" alt="Image de la serre" onclick="openLightbox(this.src)">
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        </main>
    </div>

    <!-- Lightbox pour afficher les images en grand -->
    <div id="lightbox" class="lightbox" onclick="closeLightbox()">
        <span class="close-btn">&times;</span>
        <img id="lightbox-img" src="" alt="Agrandissement">
    </div>

    <!-- Footer -->
    <?php include '../templates/footer.php'; ?>

    <script>
        function openLightbox(src) {
            document.getElementById('lightbox-img').src = src;
            document.getElementById('lightbox').style.display = "flex";
        }
        
        function closeLightbox() {
            document.getElementById('lightbox').style.display = "none";
        }
    </script>

</body>
</html>
