<?php
include '../pages/auth.php';  // Connexion à la page d'authentification

require_once '../db/db_connect.php';  // Connexion à la base de données
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historique - Serre Connectée</title>
    
    <!-- Liens vers les fichiers CSS et librairies -->
    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <header>    
        <h1 class="fade-in">🌿 Mesure</h1>
    </header>    

    <?php include '../templates/navbar.php'; ?>

    <div class="container">
        <main class="dashboard">
            <section class="content">
                <h2>📊 Données en Temps Réel</h2>

                <?php if (!$isUserLoggedIn): ?>
                    <p>🔒 L’accès aux données en temps réel est réservé aux utilisateurs connectés.</p>
                    <p>Veuillez vous connecter ou créer un compte pour accéder à ces informations.</p>

                    <div class="button-container">
                        <a href="../pages/login.php"><button class="btn">🔑 Se connecter</button></a>
                        <a href="../pages/register.php"><button class="btn">📝 S'inscrire</button></a>
                    </div>
                <?php else: ?>
                    <p>✅ Vous êtes connecté ! Voici les données en temps réel :</p>
                    <canvas id="monGraphique"></canvas> <!-- Zone du graphique -->
    
    <script>
        let monGraphique; // Variable pour stocker le graphique

        async function chargerDonnees() {
            const reponse = await fetch("dataTEST.php"); // Récupère les données PHP
            const donnees = await reponse.json(); // Convertit en JSON

            const labels = donnees.map(item => item.date_mesure); // Dates
            const valeurs = donnees.map(item => item.valeur); // Valeurs

            if (!monGraphique) {
                // Si le graphique n'existe pas encore, on le crée
                const ctx = document.getElementById("monGraphique").getContext("2d");
                monGraphique = new Chart(ctx, {
                    type: "line",
                    data: {
                        labels: labels,
                        datasets: [{
                            label: "Valeurs",
                            data: valeurs,
                            borderColor: "blue",
                            backgroundColor: "rgba(0, 0, 255, 0.2)",
                            borderWidth: 2
                        }]
                    },
                    options: {
                        responsive: true
                    }
                });
            } else {
                // Si le graphique existe déjà, on met à jour ses valeurs
                monGraphique.data.labels = labels;
                monGraphique.data.datasets[0].data = valeurs;
                monGraphique.update(); // Mettre à jour le graphique
            }
        }

        // Charger les données au démarrage
        chargerDonnees();
        setInterval(chargerDonnees, 5000);
    </script>
                <?php endif; ?>
            </section>
        </main>
    </div>
</body>

<?php include '../templates/footer.php'; ?>
</html>
