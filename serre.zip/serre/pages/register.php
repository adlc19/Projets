<?php
session_start();
include '../db/db_connect.php'; // Connexion à la base de données

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = 'client'; // Rôle par défaut

    // Validation de l'email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Erreur : L'email n'est pas valide.";
        exit();
    }

    // Validation du mot de passe (minimum 6 caractères)
    if (strlen($password) < 6) {
        echo "Erreur : Le mot de passe doit contenir au moins 6 caractères.";
        exit();
    }

    // Hash du mot de passe
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Préparation de la requête SQL pour l'insertion
    $sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";
    if ($stmt = $conn->prepare($sql)) {
        // Bind des paramètres
        $stmt->bind_param("ssss", $username, $email, $password_hash, $role);

        // Exécution de la requête
        if ($stmt->execute()) {
            echo "Inscription réussie ! <a href='login.php'>Connectez-vous ici</a>";
        } else {
            echo "Erreur : " . htmlspecialchars($stmt->error); // Échapper l'erreur pour éviter XSS
        }
        $stmt->close();
    } else {
        echo "Erreur de préparation de la requête SQL.";
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serre Connectée</title>
    
    <!-- Liens vers les fichiers CSS et librairies -->
    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body class="register-page">

    <header>    
        <h1 class="fade-in">🌿 S'inscrire</h1>
    </header>    

    <?php include '../templates/navbar.php'; ?>

    <div class="form-container">
        <form action="register.php" method="POST">
            <input type="text" name="username" placeholder="Nom d'utilisateur" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Mot de passe" required>
            <button type="submit">S'inscrire</button>
        </form>
        <p>Déjà inscrit ? <a href="login.php">Connectez-vous</a></p>
    </div>
</body>

<?php include '../templates/footer.php'; ?>
</html>
