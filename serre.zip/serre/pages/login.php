<?php
// Démarrer la session de manière sécurisée
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true, // Empêche JavaScript d'accéder aux cookies
        'cookie_secure' => isset($_SERVER['HTTPS']), // Active uniquement en HTTPS
        'cookie_samesite' => 'Strict', // Protection contre CSRF
    ]);
}

// Connexion à la base de données
require_once '../db/db_connect.php';

$error_message = '';

// Générer un token CSRF si non existant
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Gestion de la connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("⚠️ Requête invalide !");
    }
    unset($_SESSION['csrf_token']); // 🔥 On détruit le token après validation pour éviter le "double submit"

    // Vérifier les identifiants (Nom d'utilisateur + Mot de passe)
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Sécuriser l'entrée utilisateur
    function secureInput($data) {
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
    $username = secureInput($username);

    $stmt = $conn->prepare("SELECT id, password, role FROM users WHERE username = ?");
    if ($stmt) {
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result(); // 🔹 Empêche certaines attaques SQL
        $stmt->bind_result($user_id, $hashed_password, $role);
        $stmt->fetch();

        if ($stmt->num_rows > 0) { // 🔥 On vérifie qu’un utilisateur existe
            if (password_verify($password, $hashed_password)) {
                // ✅ Connexion réussie
                $_SESSION['user_id'] = $user_id;
                $_SESSION['role'] = $role; // 🔥 On stocke aussi le rôle pour la navbar

                header("Location: ../index.php"); // ✅ Redirection après connexion
                exit();
            } else {
                $error_message = '❌ Mot de passe incorrect.';
            }
        } else {
            $error_message = '❌ Utilisateur non trouvé.';
        }
        $stmt->close();
    } else {
        $error_message = '❌ Une erreur est survenue lors de la connexion.';
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Serre Connectée</title>

    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">

    <style>
        .login-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .login-container h3 {
            color: #007bff;
            font-size: 22px;
            margin-bottom: 20px;
        }

        .login-container label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        .login-container input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .login-container button {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .login-container button:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <h1 class="fade-in">🔑 Connexion</h1>
    </header>

    <?php include '../templates/navbar.php'; ?>

    <div class="container">
        <main class="dashboard">
            <section class="content">
                <div class="login-container">
                    <h3>Se connecter</h3>
                    
                    <?php if (!empty($error_message)): ?>
                        <p class="error-message"><?php echo htmlspecialchars($error_message, ENT_QUOTES, 'UTF-8'); ?></p>
                    <?php endif; ?>

                    <form action="login.php" method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                        <label for="username">Nom d'utilisateur :</label>
                        <input type="text" name="username" required>

                        <label for="password">Mot de passe :</label>
                        <input type="password" name="password" required>

                        <button type="submit">Se connecter</button>
                    </form>
                </div>
            </section>
        </main>
    </div>

    <?php include '../templates/footer.php'; ?>
</body>
</html>
