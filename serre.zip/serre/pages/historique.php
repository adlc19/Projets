<?php
// Inclusion du fichier de vérification de session
include '../pages/auth.php';

// Connexion à la base de données
require_once '../db/db_connect.php'; 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historique - Serre Connectée</title>
    
    <!-- Liens vers les fichiers CSS et librairies -->
    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="container">
    <header>    
        <h1 class="fade-in">🌿 Historique</h1>
    </header>    
        <?php include '../templates/navbar.php'; ?>

    <div class="container">
        <main class="dashboard">
    <section class="content">
        <h2>📊 Historique</h2>

        <?php if (!$isUserLoggedIn): ?>
            <p>🔒 L’accès à l'historique est réservé aux utilisateurs connectés.</p>
            <p>Veuillez vous connecter ou créer un compte pour accéder à ces informations.</p>

            <div class="button-container">
                <a href="../pages/login.php"><button class="btn">🔑 Se connecter</button></a>
                <a href="../pages/register.php"><button class="btn">📝 S'inscrire</button></a>
            </div>
        <?php else: ?>
            <p>✅ Vous êtes connecté ! Voici l'historique des données :</p>

            <!-- ⚡ Ajoute ici le code pour afficher l'historique, par exemple -->
            <div class="historique-data">
                <?php
                // Sécurisation des données venant de la base de données
                $stmt = $conn->prepare("SELECT date, mesure FROM historique ORDER BY date DESC LIMIT 10");
                $stmt->execute();
                $result = $stmt->get_result();

                // Affichage des résultats de manière sécurisée
                while ($row = $result->fetch_assoc()) {
                    echo "<p><strong>" . htmlspecialchars($row['date']) . "</strong> : " . htmlspecialchars($row['mesure']) . "</p>";
                }

                $stmt->close();
                ?>
            </div>
        <?php endif; ?>
    </section>
</main>


    </div>
    </div>
</body>

<?php include '../templates/footer.php'; ?>
</html>
