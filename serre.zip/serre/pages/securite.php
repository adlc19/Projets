<?php
// Démarrer la session avec des paramètres sécurisés
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,  // Empêche l'accès aux cookies via JavaScript
        'cookie_secure' => isset($_SERVER['HTTPS']),  // Active uniquement en HTTPS
        'cookie_samesite' => 'Strict',  // Protège contre les attaques CSRF
    ]);
}

// Vérifier si l'utilisateur est connecté
$user_connected = isset($_SESSION['user_id']);

// Générer un token CSRF si non existant
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Connexion à la base de données
require_once '../db/db_connect.php';

// Fonction pour sécuriser les entrées utilisateurs
function secureInput($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serre Connectée - Sécurité</title>
    
    <!-- Liens vers les fichiers CSS et librairies -->
    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <style>
        .security-container {
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .security-container h3 {
            color: #007bff;
            font-size: 22px;
            margin-bottom: 20px;
        }

        .security-container label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        .security-container input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .security-container button {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .security-container button:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: red;
            font-size: 18px;
            font-weight: bold;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>    
        <h1 class="fade-in">🌿 Sécurité</h1>
    </header>    

    <?php include '../templates/navbar.php'; ?>

    <div class="container">
        <main class="dashboard">
            <section class="content">
                <h2>🛡️ Sécuriser votre compte</h2>
                
                <?php if (!$user_connected): ?>
                    <p class="error-message">⚠️ Accès limité. Veuillez <a href="login.php">vous connecter</a> pour accéder à cette page.</p>
                <?php else: ?>
                    <p>Sur cette page, vous pouvez consulter et gérer les paramètres de sécurité de votre compte.</p>

                    <!-- ✅ FORMULAIRE DE CHANGEMENT DE MOT DE PASSE -->
                    <div class="security-container">
                        <h3>🔑 Changer votre mot de passe</h3>
                        <form action="../db/change_password.php" method="POST">
                            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">

                            <label for="old_password">Ancien mot de passe :</label>
                            <input type="password" name="old_password" required>

                            <label for="new_password">Nouveau mot de passe :</label>
                            <input type="password" name="new_password" required>

                            <label for="confirm_password">Confirmer le nouveau mot de passe :</label>
                            <input type="password" name="confirm_password" required>

                            <button type="submit">Changer le mot de passe</button>
                        </form>
                    </div>
                <?php endif; ?>
            </section>
        </main>
    </div>

    <?php include '../templates/footer.php'; ?>
</body>
</html>
