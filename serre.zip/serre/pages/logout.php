<?php
session_start();

// Sécuriser la session avant de la détruire
if (isset($_SESSION['user_id'])) {
    // Regénérer l'ID de session pour prévenir les attaques de fixation de session
    session_regenerate_id(true);

    // Détruire la session
    session_unset();
    session_destroy();
    
    // Redirection vers la page d'accueil après déconnexion
    header("Location: ../index.php");
    exit();
} else {
    // Si la session n'est pas active, rediriger vers la page d'accueil
    header("Location: ../index.php");
    exit();
}
?>
