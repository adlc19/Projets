<?php include '../templates/navbar.php'; ?>

<?php include '../templates/footer.php'; ?>

<?php
if (isset($_COOKIE['user_session'])) {
    echo "Le cookie user_session est actif : " . $_COOKIE['user_session'];
} else {
    echo "Aucun cookie user_session trouvé.";
}
?>
