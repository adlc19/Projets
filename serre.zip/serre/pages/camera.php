<?php
session_start();

// Sécuriser la variable de session pour vérifier si l'utilisateur est connecté
$isUserLoggedIn = isset($_SESSION['user_id']);

// Protection contre les injections SQL et XSS
function secureInput($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

$_SESSION['user_id'] = isset($_SESSION['user_id']) ? secureInput($_SESSION['user_id']) : null;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serre Connectée - Caméra en Direct</title>
    
    <!-- Liens CSS et bibliothèques -->
    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">
    <link rel="stylesheet" href="../assets/css/stylecamera.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
</head>

<body>
    <!-- Header -->
    <header>    
        <h1 class="fade-in">📷 Caméra en Direct</h1>
    </header>    

    <!-- Navigation -->
    <?php include '../templates/navbar.php'; ?>

    <div class="container">
        <main class="dashboard">
            <section class="content">
                <h2>Surveillance de la serre</h2>
                
                <?php if (!$isUserLoggedIn): ?>
                    <p>🔒 L’accès à la caméra est réservé aux utilisateurs connectés.</p>
                    <p>Veuillez vous connecter ou créer un compte pour voir le flux en direct.</p>

                    <div class="button-container">
                        <a href="../pages/login.php"><button class="btn">🔑 Se connecter</button></a>
                        <a href="../pages/register.php"><button class="btn">📝 S'inscrire</button></a>
                    </div>
                <?php else: ?>
                    <p>✅ Vous êtes connecté ! Voici le flux en direct de la serre :</p>
                    
                    <!-- Zone d'affichage de la caméra -->
                    <div class="camera-container" onclick="openLightbox()">
                        <img id="camera-stream" src="/camera/?action=stream" alt="Flux en direct de la serre" onerror="showErrorMessage()">
                    </div>
                    
                    <p id="error-message" style="color: red; margin-top: 10px;">
                        ⚠️ Si le flux vidéo ne s'affiche pas correctement, essayez d'y accéder directement avec ce lien :
                        <a href="http://192.168.10.102:8081/" target="_blank">http://192.168.10.102:8081/</a>
                    </p>
                <?php endif; ?>
            </section>
        </main>
    </div>

    <!-- Lightbox pour afficher la caméra en grand -->
    <div id="lightbox" class="lightbox" onclick="closeLightbox()">
        <span class="close-btn">&times;</span>
        <img id="lightbox-img" src="" alt="Flux en direct agrandi">
    </div>

    <script>
        function openLightbox() {
            document.getElementById('lightbox-img').src = document.getElementById('camera-stream').src;
            document.getElementById('lightbox').style.display = "flex";
        }
        
        function closeLightbox() {
            document.getElementById('lightbox').style.display = "none";
        }
    </script>
</body>
</html>
