<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['accept'])) {
        setcookie("user_consent", "accepted", time() + (365 * 24 * 60 * 60), "/", "", true, true);
        echo "accepted";
        exit;
    }
    if (isset($_POST['decline'])) {
        setcookie("user_consent", "declined", time() + (365 * 24 * 60 * 60), "/", "", true, true);
        echo "declined";
        exit;
    }
}
?>

<div id="cookie-modal">
    <div class="cookie-box">
        <h2>Gestion des cookies</h2>
        <p>Nous utilisons des cookies pour améliorer votre expérience. Acceptez-vous leur utilisation ?</p>
        <button id="accept-cookies">Accepter</button>
        <button id="decline-cookies">Refuser</button>
    </div>
</div>
