#!/bin/bash
/usr/bin/php /var/www/serre/insert_data.php >> /var/www/serre/insert_log.txt 2>&1
