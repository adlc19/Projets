<?php 
// Démarrer la session si elle n'est pas déjà active
if (session_status() == PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true, // Sécurise la session contre les attaques XSS
        'use_strict_mode' => true  // Empêche l'utilisation de sessions non valides
    ]);
}

// Vérifier si l'utilisateur a déjà accepté/refusé les cookies
$cookie_consent = isset($_COOKIE['cookie_consent']) ? htmlspecialchars($_COOKIE['cookie_consent'], ENT_QUOTES, 'UTF-8') : null;

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serre Connectée</title>
    
    <!-- Liens vers les fichiers CSS et librairies -->
    <link rel="stylesheet" href="assets/css/styleindex.css">
    <link rel="stylesheet" href="assets/css/stylecookies.css">
    <link rel="stylesheet" href="assets/css/animations.css">
    
    <!-- Librairies JavaScript sécurisées -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body class="<?= !$cookie_consent ? 'no-scroll' : ''; ?>">

    <header>
        <h1 class="fade-in">🌿 Bienvenue sur la Serre Connectée</h1>
    </header>

    <?php 
    // Inclure la barre de navigation si le fichier existe
    $navbar_path = './templates/navbar.php';
    if (file_exists($navbar_path)) {
        include $navbar_path;
    } else {
        error_log("Fichier navbar.php introuvable.");
    }
    ?>
    
    <section class="container">
        <h2>🌍 Présentation du Projet</h2>
        <p>La serre connectée est une solution innovante qui permet aux biologistes et agriculteurs de surveiller et contrôler les conditions climatiques en temps réel. Grâce à une automatisation intelligente, le système assure une croissance optimale des plantes en régulant la température, l'humidité et l'irrigation.</p>
        <p>Avec l'évolution des technologies, il est devenu essentiel de surveiller les cultures à distance et d'optimiser les ressources en eau et en énergie. Ce projet propose une approche complète et efficace pour répondre à ces besoins.</p>
        
        <h2>⚙️ Fonctionnalités Avancées</h2>
        <ul>
            <li>📡 <strong>Surveillance en temps réel :</strong> Affichage des données de température et d'humidité directement sur le navigateur.</li>
            <li>🌡️ <strong>Contrôle de la température :</strong> Ouverture et fermeture automatique du toit pour réguler la chaleur intérieure.</li>
            <li>💧 <strong>Gestion de l'irrigation :</strong> Activation automatique d'une pompe en fonction du taux d'humidité du sol.</li>
            <li>🌬️ <strong>Détection du vent :</strong> Fermeture automatique du toit en cas de vents forts pour protéger les cultures.</li>
            <li>📸 <strong>Surveillance visuelle :</strong> Prise de photos quotidiennes et accès aux images via une interface web.</li>
            <li>📊 <strong>Historisation des données :</strong> Enregistrement des mesures pour analyse et suivi de l'évolution.</li>
        </ul>
        
        <h2>🛠️ Technologies Utilisées</h2>
        <ul>
            <li>🔌 <strong>Matériel :</strong> Arduino Nano pour le contrôle des capteurs et actionneurs.</li>
            <li>📡 <strong>Réseau :</strong> Raspberry Pi pour gérer le serveur et la caméra.</li>
            <li>🌦️ <strong>Capteurs :</strong> Température, humidité, anémomètre pour la détection du vent.</li>
            <li>💾 <strong>Base de données :</strong> Stockage des mesures sur un serveur pour consultation et analyse.</li>
        </ul>
        
        <h2>🚀 Accès aux Services</h2>
        <p><a href="mesures.php" class="btn">🔍 Voir les données en temps réel</a></p>
        <p><a href="historique.php" class="btn">📊 Consulter l'historique des mesures</a></p>
        <p><a href="camera.php" class="btn">📷 Visualiser la serre en direct</a></p>
    </section>
    
    <?php if (!$cookie_consent): ?>
        <div class="overlay"></div>
        <div id="cookie-popup">
            <div class="cookie-container">
                <h2>Gestion des cookies 🍪</h2>
                <p>Nous utilisons des cookies pour améliorer votre expérience.</p>
                <p>Vous pouvez accepter tous les cookies, refuser ou choisir vos préférences.</p>

                <button id="acceptCookies">Tout accepter</button>
                <button id="declineCookies">Tout refuser</button>
                <button id="customizeCookies">Personnaliser</button>

                <div id="customOptions" class="hidden">
                    <p>Choisissez les cookies que vous acceptez :</p>
                    <label><input type="checkbox" id="functionalCookies" checked> Cookies fonctionnels</label><br>
                    <label><input type="checkbox" id="analyticsCookies"> Cookies analytiques</label><br>
                    <label><input type="checkbox" id="adsCookies"> Cookies publicitaires</label><br>
                    <button id="savePreferences">Enregistrer mes choix</button>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php 
    // Chargement du script cookies uniquement si le fichier existe
    $cookies_script = "assets/js/cookies.js";
    if (file_exists($cookies_script)): ?>
        <script src="<?= $cookies_script ?>"></script>
    <?php else: ?>
        <script>console.error("Le fichier JavaScript cookies.js est introuvable.");</script>
    <?php endif; ?>
</body>
</html>
