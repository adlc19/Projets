#!/bin/bash

# Vérifier si le fichier JSON existe et n'est pas vide
if [ -s /var/www/serre/donnees_temp.json ]; then
    # Lire le contenu du fichier
    DATA=$(cat /var/www/serre/donnees_temp.json)
    
    # Extraire les valeurs
    TEMPERATURE=$(echo $DATA | jq -r '.temperature')
    HUMIDITE=$(echo $DATA | jq -r '.humidite')
    DATE=$(echo $DATA | jq -r '.date')

    # Insérer les données en base via PHP
    /usr/bin/php /var/www/serre/insert_data.php temperature=$TEMPERATURE humidite=$HUMIDITE date=$DATE

    # Vider le fichier après l'insertion
    echo "" > /var/www/serre/donnees_temp.json
fi
