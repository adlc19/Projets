<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'technicien') {
    header("Location: ../index.php");
    exit();
}

include '../db/db_connect.php';

// Activer la mise en mémoire tampon pour éviter l'erreur de header
ob_start();

// Récupérer les interventions
$sql = "SELECT id, titre, description, date_intervention, status FROM interventions";
$result = $conn->query($sql);

// Ajouter une intervention
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['ajouter_intervention'])) {
    $titre = filter_input(INPUT_POST, 'titre', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $date_intervention = filter_input(INPUT_POST, 'date_intervention', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $technicien_id = $_SESSION['user_id'];

    if (!empty($titre) && !empty($description) && !empty($date_intervention)) {
        $sql_insert = "INSERT INTO interventions (titre, description, date_intervention, technicien_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql_insert);
        $stmt->bind_param("sssi", $titre, $description, $date_intervention, $technicien_id);

        if ($stmt->execute()) {
            header("Location: interventions.php?success=1");
            exit();
        } else {
            header("Location: interventions.php?error=1");
            exit();
        }
    }
}

// Mettre à jour le statut d’une intervention
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_status'])) {
    $intervention_id = filter_input(INPUT_POST, 'intervention_id', FILTER_VALIDATE_INT);
    $new_status = filter_input(INPUT_POST, 'new_status', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    $valid_status = ['En attente', 'En cours', 'Terminé'];

    if ($intervention_id && in_array($new_status, $valid_status)) {
        $sql_update = "UPDATE interventions SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update);
        $stmt->bind_param("si", $new_status, $intervention_id);

        if ($stmt->execute()) {
            header("Location: interventions.php?updated=1");
            exit();
        } else {
            header("Location: interventions.php?error=1");
            exit();
        }
    }
}

ob_end_flush(); // Libérer le buffer et envoyer la sortie
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>🔧 Interventions</title>
    <link rel="stylesheet" href="../assets/css/styleinterventions.css">
</head>
<body>
    <header>    
        <h1 class="fade-in">🔧 Interventions</h1>
    </header>    
    <?php include '../templates/navbar.php'; ?>
        
    <div class="container">
        <div class="table-container">
            <h2>📋 Liste des Interventions</h2>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Titre</th>
                        <th>Description</th>
                        <th>Date</th>
                        <th>Statut</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']) ?></td>
                            <td><?= htmlspecialchars($row['titre']) ?></td>
                            <td><?= htmlspecialchars($row['description']) ?></td>
                            <td><?= htmlspecialchars($row['date_intervention']) ?></td>
                            <td>
                                <span class="status <?= strtolower(htmlspecialchars($row['status'])) ?>">
                                    <?= htmlspecialchars($row['status']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($row['status'] !== 'Terminé') : ?>
                                    <form method="POST" class="status-form">
                                        <input type="hidden" name="intervention_id" value="<?= htmlspecialchars($row['id']) ?>">
                                        <select name="new_status">
                                            <option value="En attente" <?= $row['status'] == 'En attente' ? 'selected' : '' ?>>En attente</option>
                                            <option value="En cours" <?= $row['status'] == 'En cours' ? 'selected' : '' ?>>En cours</option>
                                            <option value="Terminé" <?= $row['status'] == 'Terminé' ? 'selected' : '' ?>>Terminé</option>
                                        </select>
                                        <button type="submit" name="update_status">🔄 Mettre à jour</button>
                                    </form>
                                <?php else: ?>
                                    ✅ <span class="status termine">Terminé</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="form-container">
            <h2>➕ Ajouter une Intervention</h2>
            <form method="POST">
                <label>Titre :</label>
                <input type="text" name="titre" required>

                <label>Description :</label>
                <textarea name="description" required></textarea>

                <label>Date :</label>
                <input type="datetime-local" name="date_intervention" required>

                <button type="submit" name="ajouter_intervention">📩 Ajouter</button>
            </form>
        </div>
    </div>
    
    <?php include '../templates/footer.php'; ?>
</body>
</html>
