<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'technicien') {
    header("Location: ../index.php");
    exit();
}

include '../db/db_connect.php';

// Activer la mise en mémoire tampon pour éviter l'erreur de header
ob_start();

// Récupérer les équipements
$sql = "SELECT id, nom, description, etat FROM equipements";
$result = $conn->query($sql);

// Ajouter un équipement
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['ajouter_equipement'])) {
    $nom = filter_input(INPUT_POST, 'nom', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $etat = 'fonctionnel';
    $technicien_id = $_SESSION['user_id'];

    if (!empty($nom) && !empty($description)) {
        $sql_insert = "INSERT INTO equipements (nom, description, etat, technicien_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql_insert);
        $stmt->bind_param("sssi", $nom, $description, $etat, $technicien_id);

        if ($stmt->execute()) {
            header("Location: equipements.php?success=1");
            exit();
        } else {
            header("Location: equipements.php?error=1");
            exit();
        }
    }
}

// Mettre à jour l’état d’un équipement
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_etat'])) {
    $equipement_id = filter_input(INPUT_POST, 'equipement_id', FILTER_VALIDATE_INT);
    $etat = filter_input(INPUT_POST, 'etat', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    $valid_etats = ['fonctionnel', 'en panne', 'en maintenance'];

    if ($equipement_id && in_array($etat, $valid_etats)) {
        $sql_update = "UPDATE equipements SET etat = ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update);
        $stmt->bind_param("si", $etat, $equipement_id);

        if ($stmt->execute()) {
            header("Location: equipements.php?updated=1");
            exit();
        } else {
            header("Location: equipements.php?error=1");
            exit();
        }
    }
}

ob_end_flush(); // Libérer le buffer et envoyer la sortie
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Équipements</title>
    <link rel="stylesheet" href="../assets/css/styleequipements.css">
</head>
<body>
    <header>    
        <h1 class="fade-in">🛠️ Gestion des Équipements</h1>
    </header>    
    <?php include '../templates/navbar.php'; ?>
    
    <div class="container">
        <div class="equipements-table">
            <h2>📋 Liste des Équipements</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nom</th>
                        <th>Description</th>
                        <th>État</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']) ?></td>
                            <td><?= htmlspecialchars($row['nom']) ?></td>
                            <td><?= htmlspecialchars($row['description']) ?></td>
                            <td>
                                <span class="etat <?= htmlspecialchars($row['etat']) ?>">
                                    <?= ucfirst(htmlspecialchars($row['etat'])) ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST">
                                    <input type="hidden" name="equipement_id" value="<?= htmlspecialchars($row['id']) ?>">
                                    <select name="etat">
                                        <option value="fonctionnel" <?= $row['etat'] == 'fonctionnel' ? 'selected' : '' ?>>✅ Fonctionnel</option>
                                        <option value="en panne" <?= $row['etat'] == 'en panne' ? 'selected' : '' ?>>⚠ En Panne</option>
                                        <option value="en maintenance" <?= $row['etat'] == 'en maintenance' ? 'selected' : '' ?>>🔧 En Maintenance</option>
                                    </select>
                                    <button type="submit" name="update_etat">🔄 Mettre à jour</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="form-container">
            <h2>➕ Ajouter un Équipement</h2>
            <form method="POST">
                <label>Nom :</label>
                <input type="text" name="nom" required>

                <label>Description :</label>
                <textarea name="description" required></textarea>

                <button type="submit" name="ajouter_equipement">📩 Ajouter</button>
            </form>
        </div>
    </div>

    <?php include '../templates/footer.php'; ?>
</body>
</html>
