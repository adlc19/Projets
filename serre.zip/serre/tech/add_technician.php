<?php
include '../db/db_connect.php'; // Connexion à la base de données

// Définition des informations du technicien
$username = "tech1";
$email = "tech@gmail.com";
$password = "tech123"; // Mot de passe en clair (à ne jamais stocker directement)
$hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hachage sécurisé
$role = "technicien";
$last_activity = date('Y-m-d H:i:s'); // Date actuelle

// Préparer la requête SQL
$sql = "INSERT INTO users (username, email, password, role, last_activity) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssss", $username, $email, $hashed_password, $role, $last_activity);

// Exécuter et vérifier
if ($stmt->execute()) {
    echo "✅ Technicien ajouté avec succès !";
} else {
    echo "❌ Erreur : " . $stmt->error;
}

// Fermer la connexion
$stmt->close();
$conn->close();
?>
