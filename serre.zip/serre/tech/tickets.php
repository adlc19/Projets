<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'technicien') {
    header("Location: ../index.php");
    exit();
}

include '../db/db_connect.php'; // Connexion à la BDD

// Activer la mise en mémoire tampon pour éviter les erreurs de header
ob_start();

// Récupérer les tickets selon le filtre
$filter = filter_input(INPUT_GET, 'filter', FILTER_SANITIZE_FULL_SPECIAL_CHARS) ?? 'tous';

$sql = "SELECT * FROM tickets";
if ($filter !== 'tous') {
    $sql .= " WHERE status = ?";
}

$stmt = $conn->prepare($sql);
if ($filter !== 'tous') {
    $stmt->bind_param("s", $filter);
}
$stmt->execute();
$result = $stmt->get_result();

// Ajouter un nouveau ticket
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['ajouter_ticket'])) {
    $sujet = filter_input(INPUT_POST, 'sujet', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $status = 'ouvert'; // Par défaut
    $technicien_id = $_SESSION['user_id']; // Associer au technicien connecté

    if (!empty($sujet) && !empty($description)) {
        $sql_insert = "INSERT INTO tickets (sujet, description, status, technicien_id) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql_insert);
        $stmt->bind_param("sssi", $sujet, $description, $status, $technicien_id);

        if ($stmt->execute()) {
            header("Location: tickets.php?success=1");
            exit();
        } else {
            echo "<script>alert('❌ Erreur lors de l\'ajout du ticket');</script>";
        }
    }
}

// Marquer un ticket comme résolu
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['resolve_ticket'])) {
    $ticket_id = filter_input(INPUT_POST, 'ticket_id', FILTER_VALIDATE_INT);
    $comment = filter_input(INPUT_POST, 'comment', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    if ($ticket_id && !empty($comment)) {
        $sql_update = "UPDATE tickets SET status = 'résolu', commentaire = ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update);
        $stmt->bind_param("si", $comment, $ticket_id);

        if ($stmt->execute()) {
            header("Location: tickets.php?updated=1");
            exit();
        } else {
            echo "<script>alert('❌ Erreur lors de la mise à jour');</script>";
        }
    }
}

ob_end_flush(); // Libérer le buffer
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Tickets</title>
    <link rel="stylesheet" href="../assets/css/styletickets.css">
</head>
<body>

    <!-- Header -->
    <header>    
        <h1 class="fade-in">🎫 Gestion des Tickets</h1>
    </header>    

    <!-- Navbar -->
    <?php include '../templates/navbar.php'; ?>

    <!-- Conteneur principal -->
    <div class="container">

        <!-- Tableau des Tickets -->
        <div class="ticket-table-container">
            <h2>📋 Tickets</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Sujet</th>
                        <th>Description</th>
                        <th>Statut</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <tr>
                            <td><?= htmlspecialchars($row['id']) ?></td>
                            <td><?= htmlspecialchars($row['sujet']) ?></td>
                            <td><?= htmlspecialchars($row['description']) ?></td>
                            <td>
                                <span class="status <?= htmlspecialchars($row['status']) ?>">
                                    <?= ucfirst(htmlspecialchars($row['status'])) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($row['status'] !== 'résolu') : ?>
                                    <form method="POST" class="resolve-form">
                                        <input type="hidden" name="ticket_id" value="<?= htmlspecialchars($row['id']) ?>">
                                        <input type="text" name="comment" placeholder="Commentaire" required>
                                        <button type="submit" name="resolve_ticket">✔ Résoudre</button>
                                    </form>
                                <?php else: ?>
                                    ✅ <span class="status resolu">Résolu</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Formulaire d'ajout de Ticket -->
        <div class="form-container">
            <h2>➕ Ajouter un Ticket</h2>
            <form method="POST">
                <label>Sujet :</label>
                <input type="text" name="sujet" required>

                <label>Description :</label>
                <textarea name="description" required></textarea>

                <button type="submit" name="ajouter_ticket">📩 Ajouter</button>
            </form>
        </div>

    </div>
    
    <div style="height: 50px;"></div> <!-- Espace vide avant le footer -->
    <!-- Footer -->
    <?php include '../templates/footer.php'; ?>

</body>
</html>
