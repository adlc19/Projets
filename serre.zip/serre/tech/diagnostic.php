<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'technicien') {
    header("Location: ../index.php");
    exit();
}

include '../db/db_connect.php'; // Connexion à la BDD

// Récupérer les tickets assignés au technicien
$sql = "SELECT * FROM tickets WHERE technicien_id = ? ORDER BY status ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result_tickets = $stmt->get_result();

// Récupérer les interventions
$sql = "SELECT * FROM interventions WHERE technicien_id = ? ORDER BY date_intervention DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result_interventions = $stmt->get_result();

// Récupérer les équipements assignés
$sql = "SELECT * FROM equipements WHERE technicien_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result_equipements = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Technicien</title>
    <link rel="stylesheet" href="../assets/css/stylediagnostic.css">
</head>
<body>
    <header>    
        <h1 class="fade-in">🌿 Bienvenue Technicien</h1>
    </header> 
    <?php include '../templates/navbar.php'; ?>
    
    <div class="container">
        <h2>👨‍🔧 Tableau de bord du technicien</h2>
        
        <h3>📌 Tickets à traiter</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Sujet</th>
                <th>Statut</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result_tickets->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= isset($row['sujet']) ? htmlspecialchars($row['sujet']) : 'Sans sujet' ?></td>
                <td><?= isset($row['status']) ? ucfirst(htmlspecialchars($row['status'])) : 'Inconnu' ?></td>
                <td>
                    <a href="tickets.php?id=<?= $row['id'] ?>" class="button">Gérer</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        
        <h3>🔧 Interventions</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Description</th>
                <th>Date</th>
                <th>Statut</th>
            </tr>
            <?php while ($row = $result_interventions->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td><?= $row['date_intervention'] ?></td>
                <td><?= ucfirst(htmlspecialchars($row['status'])) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        
        <h3>📊 Équipements</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>État</th>
            </tr>
            <?php while ($row = $result_equipements->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['nom']) ?></td>
                <td><?= ucfirst(htmlspecialchars($row['etat'])) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <a href="../logout.php" class="button">Déconnexion</a>
    </div>
    
    <div style="height: 50px;"></div> <!-- Espace vide avant le footer -->
    <!-- Footer -->
    <?php include '../templates/footer.php'; ?>
</body>
</html>

