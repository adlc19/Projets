<footer>
    <div class="footer-container">
        <div class="footer-links">
            <a href="<?= htmlspecialchars('../index.php') ?>">Accueil</a>
            <a href="<?= htmlspecialchars('../pages/mesures.php') ?>">Données Temps Réel</a>
            <a href="<?= htmlspecialchars('../pages/historique.php') ?>">Historique</a>
            <a href="<?= htmlspecialchars('../pages/galerie.php') ?>">Galerie</a>
            <a href="<?= htmlspecialchars('../pages/contact.php') ?>">Contact</a>
            <a href="<?= htmlspecialchars('../pages/securite.php') ?>">Sécurité</a>
            <a href="<?= htmlspecialchars('../pages/register.php') ?>">S'inscrire</a>
            <a href="<?= htmlspecialchars('../pages/login.php') ?>">Se connecter</a>
        </div>
        
        <div class="footer-socials">
            <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer"><i class="fab fa-facebook"></i></a>
            <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer"><i class="fab fa-twitter"></i></a>
            <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer"><i class="fab fa-instagram"></i></a>
        </div>

        <p class="footer-text">© 2024 Serre Connectée - Tous droits réservés</p>
    </div>
</footer>

<!-- Animation GSAP sécurisée et optimisée -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" defer></script>
<script defer>
    document.addEventListener("DOMContentLoaded", function () {
        gsap.from(".footer-container", { opacity: 0, y: 50, duration: 1, ease: "power2.out" });
    });
</script>
