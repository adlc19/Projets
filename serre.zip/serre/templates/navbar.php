<?php
// Démarrer la session de manière sécurisée
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 0, // Cookie expire à la fermeture du navigateur
        'cookie_secure' => isset($_SERVER['HTTPS']), // Le cookie est envoyé uniquement en HTTPS
        'cookie_httponly' => true, // Empêche l'accès au cookie via JavaScript
        'use_strict_mode' => true // Active le mode strict pour renforcer la sécurité
    ]);
    session_regenerate_id(true); // Change l'ID de session pour éviter les attaques de fixation de session
}

// Debug temporaire pour vérifier les valeurs de session (À SUPPRIMER EN PROD)
// echo "<pre>"; print_r($_SESSION); echo "</pre>";
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/styleindex.css">
    <link rel="stylesheet" href="../assets/css/animations.css">
    
    <!-- Scripts avec 'defer' pour améliorer les performances -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js" defer></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous" defer></script>
</head>
<body>
    <nav class="navbar">
        <ul class="nav-links">
            <li><a href="../index.php">🏠 Accueil</a></li>
            <li><a href="../pages/mesures.php">📊 Données Temps Réel</a></li>
            <li><a href="../pages/historique.php">📜 Historique</a></li>
            <li><a href="../pages/galerie.php">🖼 Galerie</a></li>
            <li><a href="../pages/camera.php">📷 Caméra</a></li>
            <li><a href="../pages/contact.php">📩 Contact</a></li>
            <li><a href="../pages/securite.php">🔒 Sécurité</a></li>

            <?php if (!empty($_SESSION['user_id']) && isset($_SESSION['role'])): ?>
                <?php if ($_SESSION['role'] === 'admin'): ?>
                    <li><a href="../admin/dashboard.php">⚙️ Admin</a></li>
                <?php endif; ?>

                <?php if ($_SESSION['role'] === 'technicien'): ?>
                    <li><a href="../tech/diagnostic.php">🛠 Diagnostic</a></li>
                    <li><a href="../tech/tickets.php">🎫 Tickets</a></li>
                    <li><a href="../tech/interventions.php">🛠 Interventions</a></li>
                    <li><a href="../tech/equipements.php">🛠 Équipements</a></li>
                <?php endif; ?>

                <li><a href="../logout.php">🚪 Déconnexion</a></li>
            <?php else: ?>
                <li><a href="../pages/register.php">📝 S'inscrire</a></li>
                <li><a href="../pages/login.php">🔑 Se connecter</a></li>
            <?php endif; ?>
        </ul>
        <button id="themeToggle" class="theme-button">🌙 Mode sombre</button>
    </nav>
    
    <!-- Fichiers JS -->
    <script src="../assets/js/animations.js" defer></script>
    <script src="../assets/js/script.js" defer></script>
</body>
</html>
