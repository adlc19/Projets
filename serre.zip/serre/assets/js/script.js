
document.addEventListener("DOMContentLoaded", () => {
    const themeToggle = document.getElementById("themeToggle");
    const body = document.body;

    // Vérifier si un thème est stocké dans le localStorage
    if (localStorage.getItem("dark-mode") === "enabled") {
        body.classList.add("dark-mode");
        themeToggle.textContent = "🌕 Mode clair"; // Mettre à jour le texte du bouton
    } else {
        themeToggle.textContent = "🌙 Mode sombre"; // Mode par défaut
    }

    themeToggle.addEventListener("click", () => {
        body.classList.toggle("dark-mode");
        
        // Sauvegarder la préférence de mode sombre dans le localStorage
        if (body.classList.contains("dark-mode")) {
            localStorage.setItem("dark-mode", "enabled");
            themeToggle.textContent = "🌕 Mode clair"; // Mettre à jour le texte du bouton
        } else {
            localStorage.setItem("dark-mode", "disabled");
            themeToggle.textContent = "🌙 Mode sombre"; // Mettre à jour le texte du bouton
        }
    });
});
