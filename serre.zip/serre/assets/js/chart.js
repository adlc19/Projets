function drawChart(ctx, label, data, color) {
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.map(d => d.timestamp),
            datasets: [{
                label: label,
                data: data.map(d => d.value),
                borderColor: color,
                fill: false
            }]
        }
    });
}
