document.addEventListener("DOMContentLoaded", function () {
    gsap.from("h1", { duration: 1.2, opacity: 0, y: -50, ease: "bounce.out" });
    gsap.from(".content", { duration: 1.5, opacity: 0, y: 50, ease: "power2.out", delay: 0.5 });
});
