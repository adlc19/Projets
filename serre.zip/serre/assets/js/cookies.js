document.addEventListener("DOMContentLoaded", function () {
    const acceptBtn = document.getElementById("acceptCookies");
    const declineBtn = document.getElementById("declineCookies");
    const customizeBtn = document.getElementById("customizeCookies");
    const saveBtn = document.getElementById("savePreferences");
    const customOptions = document.getElementById("customOptions");
    const overlay = document.querySelector(".overlay");
    const cookiePopup = document.getElementById("cookie-popup");
    const body = document.body;

    function closePopup() {
        overlay.style.display = "none";
        cookiePopup.style.display = "none";
        body.classList.remove("no-scroll");
    }

    // Accepter tous les cookies
    acceptBtn.addEventListener("click", function () {
        document.cookie = "cookie_consent=accepted; path=/; max-age=3600"; // 1 heure
        closePopup();
    });

    // Refuser tous les cookies
    declineBtn.addEventListener("click", function () {
        document.cookie = "cookie_consent=declined; path=/; max-age=3600";
        closePopup();
    });

    // Afficher les préférences avancées
    customizeBtn.addEventListener("click", function () {
        customOptions.classList.toggle("hidden");
    });

    // Sauvegarde des préférences
    saveBtn.addEventListener("click", function () {
        let preferences = [];
        if (document.getElementById("functionalCookies").checked) preferences.push("functional");
        if (document.getElementById("analyticsCookies").checked) preferences.push("analytics");
        if (document.getElementById("adsCookies").checked) preferences.push("ads");

        document.cookie = "cookie_consent=" + preferences.join(",") + "; path=/; max-age=3600";
        closePopup();
    });
});
