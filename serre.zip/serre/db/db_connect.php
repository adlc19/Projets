<?php
// Chargement des variables d'environnement (à configurer dans un fichier .env sécurisé)
$host = "localhost";
$user = "root";    // À remplacer par ton utilisateur
$pass = "root";    // À remplacer par ton mot de passe
$dbname = "SerreConnectee"; // Nom de la base de données

// Connexion sécurisée avec gestion des erreurs
$conn = new mysqli($host, $user, $pass, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    error_log("Erreur de connexion : " . $conn->connect_error);
    exit("Erreur de connexion à la base de données.");
}

// Définition du jeu de caractères pour éviter les problèmes d'encodage
$conn->set_charset("utf8mb4");

// Mise à jour de l'activité utilisateur si une session est active
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Requête préparée pour éviter l'injection SQL
    $sql = "UPDATE users SET last_activity = NOW() WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
    } else {
        error_log("Erreur lors de la préparation de la requête : " . $conn->error);
    }
}
?>
