<?php
session_start();
require 'db_connect.php'; // Connexion à la base de données

if (!isset($_SESSION['user_id'])) {
    die("Accès non autorisé.");
}

$message = ""; // Variable pour stocker le message de retour
$message_type = ""; // Type de message (succès ou erreur)

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $message = "❌ Les nouveaux mots de passe ne correspondent pas.";
        $message_type = "error";
    } else {
        // Vérifier la connexion à la base de données
        if (!$conn) {
            $message = "❌ Erreur de connexion à la base de données.";
            $message_type = "error";
        } else {
            // Récupérer le mot de passe actuel de l'utilisateur
            $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
            if (!$stmt) {
                $message = "❌ Erreur de requête SQL.";
                $message_type = "error";
            } else {
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->bind_result($hashed_password);
                $stmt->fetch();
                $stmt->close();

                if (!password_verify($old_password, $hashed_password)) {
                    $message = "❌ L'ancien mot de passe est incorrect.";
                    $message_type = "error";
                } else {
                    // Hacher le nouveau mot de passe et le mettre à jour
                    $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    if (!$stmt) {
                        $message = "❌ Erreur de préparation de la requête.";
                        $message_type = "error";
                    } else {
                        $stmt->bind_param("si", $new_hashed_password, $user_id);

                        if ($stmt->execute()) {
                            $message = "✅ Mot de passe mis à jour avec succès !";
                            $message_type = "success";
                        } else {
                            $message = "❌ Erreur lors de la mise à jour.";
                            $message_type = "error";
                        }

                        $stmt->close();
                    }
                }
            }
        }
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Changement de mot de passe</title>
    <link rel="stylesheet" href="../assets/css/styleindex.css"> <!-- Assure-toi que ce fichier CSS existe -->
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
            background-color: #f4f4f4;
        }
        .message {
            padding: 15px;
            border-radius: 5px;
            width: 50%;
            margin: auto;
            font-weight: bold;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

    <!-- Affichage du message -->
    <?php if (!empty($message)): ?>
        <div class="message <?php echo $message_type; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <!-- Bouton Retour -->
    <a href="../pages/securite.php" class="btn">🔙 Retour à la sécurité</a>

</body>
</html>
