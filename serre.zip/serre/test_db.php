
<?php
require_once 'db/db_connect.php';

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
} else {
    echo "Connexion réussie à la base de données !";
}

$conn->close();
?>
