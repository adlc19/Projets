<?php
// Activer les erreurs pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Inclure le fichier de connexion // ⚠️ Remplace par le bon chemin
require_once 'db/db_connect.php';
// Vérifier si les données GET sont présentes
if (isset($_GET['temperature']) && isset($_GET['humidite'])) {
    $temperature = $_GET['temperature'];
    $humidite = $_GET['humidite'];

    // Vérifier que les données sont bien numériques
    if (!is_numeric($temperature) || !is_numeric($humidite)) {
        exit("Données invalides.");
    }

    // Récupérer les capteurs associés depuis la base de données
    $sql_temp = "SELECT sensor_id FROM Capteur WHERE sensor_type = 'temperature' LIMIT 1";
    $sql_humid = "SELECT sensor_id FROM Capteur WHERE sensor_type = 'humidite' LIMIT 1";

    $result_temp = $conn->query($sql_temp);
    $result_humid = $conn->query($sql_humid);

    if ($result_temp->num_rows > 0 && $result_humid->num_rows > 0) {
        $row_temp = $result_temp->fetch_assoc();
        $row_humid = $result_humid->fetch_assoc();
        
        $id_capteur_temp = $row_temp['sensor_id'];
        $id_capteur_humid = $row_humid['sensor_id'];
        
        $unite_temp = "°C";
        $unite_humid = "%";
        $date_mesure = date("Y-m-d H:i:s"); // Date actuelle

        // Requête préparée pour insérer les données
        $sql = "INSERT INTO Mesure (id_capteur, valeur, unité, date_mesure) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            // Insérer la température
            $stmt->bind_param("idss", $id_capteur_temp, $temperature, $unite_temp, $date_mesure);
            if (!$stmt->execute()) {
                echo "Erreur insertion température : " . $stmt->error;
            }

            // Insérer l'humidité
            $stmt->bind_param("idss", $id_capteur_humid, $humidite, $unite_humid, $date_mesure);
            if (!$stmt->execute()) {
                echo "Erreur insertion humidité : " . $stmt->error;
            } else {
                echo "Données insérées avec succès.";
            }

            $stmt->close();
        } else {
            echo "Erreur préparation requête : " . $conn->error;
        }
    } else {
        echo "Aucun capteur trouvé.";
    }
} else {
    echo "Données manquantes.";
}
// Activer les erreurs pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Vérifier si les données GET sont présentes
if (isset($_GET['temperature']) && isset($_GET['humidite'])) {
    $temperature = $_GET['temperature'];
    $humidite = $_GET['humidite'];

    // Vérifier que les données sont bien numériques
    if (!is_numeric($temperature) || !is_numeric($humidite)) {
        exit("Données invalides.");
    }

    // Stocker dans un fichier temporaire
    $data = [
        "temperature" => $temperature,
        "humidite" => $humidite,
        "date" => date("Y-m-d H:i:s")
    ];
    
    file_put_contents('/var/www/serre/donnees_temp.json', json_encode($data));

    echo "Données reçues et stockées.";
} else {
    echo "Données manquantes.";
}


// Fermer la connexion
$conn->close();
?>
