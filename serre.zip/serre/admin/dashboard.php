<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

include '../db/db_connect.php';

// Récupération sécurisée de la liste des utilisateurs
$sql = "SELECT id, username, email, role FROM users";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result_users = $stmt->get_result();

// Récupération des logs de connexion
$sql = "SELECT login_logs.id, login_logs.user_id, users.username, login_logs.login_time, login_logs.status 
        FROM login_logs 
        LEFT JOIN users ON login_logs.user_id = users.id 
        ORDER BY login_logs.login_time DESC LIMIT 10";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result_logs = $stmt->get_result();

// Récupération des utilisateurs actifs (dans les 5 dernières minutes)
$sql = "SELECT id, username FROM users WHERE last_activity >= NOW() - INTERVAL 5 MINUTE";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result_online = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/styledashboard.css">
</head>
<body>

    <div class="header">
        Bienvenue <?= htmlspecialchars($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>
    </div>
    <?php include '../templates/navbar.php'; ?>
    
    <div class="container">
        <h2>Gestion des utilisateurs</h2>

        <table>
            <tr>
                <th>ID</th>
                <th>Nom d'utilisateur</th>
                <th>Email</th>
                <th>Rôle</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result_users->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= htmlspecialchars($row['username'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= htmlspecialchars($row['role'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td>
                    <a href="edit_user.php?id=<?= urlencode($row['id']); ?>" class="button">Modifier</a>
                    <a href="delete_user.php?id=<?= urlencode($row['id']); ?>" class="button" onclick="return confirm('Confirmer la suppression ?');">Supprimer</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        
        <h2>📌 Tentatives de connexion</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Utilisateur</th>
                <th>Date</th>
                <th>Statut</th>
            </tr>
            <?php while ($log = $result_logs->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($log['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= !empty($log['username']) ? htmlspecialchars($log['username'], ENT_QUOTES, 'UTF-8') : '<em>Inconnu</em>'; ?></td>
                <td><?= htmlspecialchars($log['login_time'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= $log['status'] === 'success' ? '✅' : '❌'; ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
       
    </div>
    
    <div class="container">
        <h2>👤 Utilisateurs en ligne</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Nom d'utilisateur</th>
            </tr>
            <?php while ($user = $result_online->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($user['id'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <a href="../logout.php" class="button">Déconnexion</a>
    </div>

    <div style="height: 50px;"></div> <!-- Espace vide avant le footer -->
    
    <?php include '../templates/footer.php'; ?>
</body>
</html>
