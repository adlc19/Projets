<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

include '../db/db_connect.php';

// Vérifier si l'ID est valide
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET['id'];

// Récupérer les informations de l'utilisateur
$sql = "SELECT username, email, role FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    header("Location: dashboard.php");
    exit();
}

// Vérification du token CSRF et mise à jour du rôle
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['csrf_token'])) {
    if ($_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $new_role = $_POST['role'];

        // Vérification des valeurs autorisées pour éviter les injections
        $valid_roles = ['client', 'admin', 'technicien'];
        if (!in_array($new_role, $valid_roles, true)) {
            $error_message = "Rôle invalide.";
        } else {
            $update_sql = "UPDATE users SET role = ? WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("si", $new_role, $id);
            if ($stmt->execute()) {
                header("Location: dashboard.php");
                exit();
            } else {
                $error_message = "Erreur lors de la mise à jour.";
            }
        }
    } else {
        $error_message = "Erreur de sécurité. Veuillez réessayer.";
    }
}

// Générer un token CSRF unique
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier Utilisateur</title>
    <link rel="stylesheet" href="../assets/css/styledashboard.css">
</head>
<body>

    <div class="form-container">
        <h2>Modifier l'utilisateur</h2>
        <p><strong>Nom:</strong> <?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></p>

        <?php if (isset($error_message)) echo "<p style='color: red;'>$error_message</p>"; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token']; ?>">
            <label for="role">Rôle :</label>
            <select name="role" id="role">
                <option value="client" <?= $user['role'] === 'client' ? 'selected' : ''; ?>>Client</option>
                <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                <option value="technicien" <?= $user['role'] === 'technicien' ? 'selected' : ''; ?>>Technicien</option>
            </select>
            <div class="button-container">
                <button type="submit" class="button">Modifier</button>
                <a href="dashboard.php" class="back-button">Annuler</a>
            </div>
        </form>
    </div>

</body>
</html>
