<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

include '../db/db_connect.php';

// Vérifier si l'ID est valide
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    header("Location: dashboard.php");
    exit();
}

$id = $_GET['id'];

// Récupérer les informations de l'utilisateur
$sql = "SELECT username, email FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    header("Location: dashboard.php");
    exit();
}

// Vérification du token CSRF
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['csrf_token'])) {
    if ($_POST['csrf_token'] === $_SESSION['csrf_token']) {
        $delete_sql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            header("Location: dashboard.php");
            exit();
        } else {
            $error_message = "Erreur lors de la suppression.";
        }
    } else {
        $error_message = "Erreur de sécurité. Veuillez réessayer.";
    }
}

// Générer un token CSRF unique
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Supprimer Utilisateur</title>
    <link rel="stylesheet" href="../assets/css/styledashboard.css">
</head>
<body>

    <div class="form-container">
        <h2>Supprimer l'utilisateur</h2>
        <p><strong>Nom:</strong> <?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></p>
        <p style="color: red;">⚠️ Cette action est irréversible !</p>

        <?php if (isset($error_message)) echo "<p style='color: red;'>$error_message</p>"; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token']; ?>">
            <div class="button-container">
                <button type="submit" class="button" style="background: #e74c3c;">Supprimer</button>
                <a href="dashboard.php" class="back-button">Annuler</a>
            </div>
        </form>
    </div>

</body>
</html>
